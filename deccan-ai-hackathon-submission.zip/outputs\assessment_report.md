# Skill Assessment Report

**Job Title:** Job Title: Software Engineer Intern
**Assessment Date:** 2026-04-27 00:48

---

## Summary

Assessment completed for 3 skill(s). Overall match score: 88.9/100. Strengths: FastAPI, Python. Personalised learning plan: 80 hours (~8 weeks).

## Overall Match Score

**88.9 / 100** █████████░

## Skill Assessments

### FastAPI ✅
- **Required:** INTERMEDIATE
- **Assessed:** INTERMEDIATE (confidence: 85%)
- **Justification:** Candidate demonstrated a clear understanding of the core concepts and provided practical examples.
- **Evidence:**
  - Correctly described architectural patterns
  - Showed familiarity with common libraries

### PostgreSQL 🟠
- **Required:** ADVANCED
- **Assessed:** INTERMEDIATE (confidence: 85%)
- **Justification:** Candidate demonstrated a clear understanding of the core concepts and provided practical examples.
- **Evidence:**
  - Correctly described architectural patterns
  - Showed familiarity with common libraries

### Python ✅
- **Required:** ADVANCED
- **Assessed:** ADVANCED (confidence: 95%)
- **Justification:** Candidate showed deep knowledge of Python internals and best practices.
- **Evidence:**
  - Expertly explained GIL and asyncio
  - Mentioned decorators and context managers

## Skill Gap Analysis

### ✅ Strengths

FastAPI, Python

### 🟠 Moderate Gaps

- **PostgreSQL**: INTERMEDIATE → ADVANCED (gap: 1)

## Visualizations

![radar_chart.png](outputs\radar_chart.png)
![gap_bar_chart.png](outputs\gap_bar_chart.png)

## Personalised Learning Plan

**Total estimated time:** 80 hours (~8 weeks)

### Step 1: PostgreSQL *(adjacent)*
- **From:** INTERMEDIATE → **To:** ADVANCED
- **Estimated time:** 80 hours
- **Milestone:** Contribute to an open-source PostgreSQL project or solve advanced problems.

**Resources:**
- 🆓 [FastAPI Masterclass](https://example.com/fastapi) — course, ~8h (Udemy)
- 🆓 [PostgreSQL — Official Documentation](https://developer.mozilla.org/en-US/docs/Web/postgresql) — documentation, ~4h (Official Docs)
- 🆓 [Learn PostgreSQL — freeCodeCamp](https://www.freecodecamp.org/news/tag/postgresql/) — tutorial, ~6h (freeCodeCamp)

### Milestones

- Milestone 1: Complete learning for PostgreSQL.

---

## Assessment Methodology

Proficiency levels: NONE (0), BEGINNER (1), INTERMEDIATE (2), ADVANCED (3), EXPERT (4). Each skill is assessed via multi-turn conversational questions. The LLM evaluates technical accuracy and depth, assigning a level with a confidence score (0–1) and justification. Gap magnitude = required_level − assessed_level. Critical gaps: required skill with magnitude ≥ 2. Moderate gaps: magnitude = 1 or non-critical skill. Match score: weighted average where required skills count 2× preferred. Adjacent skills (gap = 1) are prioritised in the learning plan.
